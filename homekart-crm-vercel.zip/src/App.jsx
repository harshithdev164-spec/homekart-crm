import React, { useEffect, useMemo, useRef, useState } from 'react'

const USERS = [
  { email: 'admin@homekart.co', password: 'admin123', role: 'admin', id:'u0', name:'Admin' },
  { email: 'agent1@homekart.co', password: 'agent123', role: 'agent', id:'u1', name:'Agent 1' },
  { email: 'agent2@homekart.co', password: 'agent123', role: 'agent', id:'u2', name:'Agent 2' },
  { email: 'agent3@homekart.co', password: 'agent123', role: 'agent', id:'u3', name:'Agent 3' },
  { email: 'agent4@homekart.co', password: 'agent123', role: 'agent', id:'u4', name:'Agent 4' },
  { email: 'agent5@homekart.co', password: 'agent123', role: 'agent', id:'u5', name:'Agent 5' },
  { email: 'agent6@homekart.co', password: 'agent123', role: 'agent', id:'u6', name:'Agent 6' },
  { email: 'agent7@homekart.co', password: 'agent123', role: 'agent', id:'u7', name:'Agent 7' },
  { email: 'agent8@homekart.co', password: 'agent123', role: 'agent', id:'u8', name:'Agent 8' },
  { email: 'agent9@homekart.co', password: 'agent123', role: 'agent', id:'u9', name:'Agent 9' },
  { email: 'agent10@homekart.co', password: 'agent123', role: 'agent', id:'u10', name:'Agent 10' },
]

const STORAGE_KEY = 'homekart_crm_state_v4'
const AUTH_KEY = 'homekart_crm_auth'
const nowISO = () => new Date().toISOString()

function seed() {
  const raw = localStorage.getItem(STORAGE_KEY)
  if (raw) return JSON.parse(raw)
  const data = {
    users: USERS.map(u => ({ id: u.id, name: u.name, role: u.role })),
    clients: [],
    inventory: [],
    requirements: [],
    chat: []
  }
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data))
  return data
}

function save(data) { localStorage.setItem(STORAGE_KEY, JSON.stringify(data)) }

function computeAnalytics(clients, inventory, requirements){
  const byStatus = clients.reduce((acc,c)=>{ acc[c.status]=(acc[c.status]||0)+1; return acc }, {})
  return {
    totalClients: clients.length,
    totalInventory: inventory.length,
    totalRequirements: requirements.length,
    hot: byStatus['Hot']||0,
    warm: byStatus['Warm']||0,
    new: byStatus['New']||0,
    closed: byStatus['Closed']||0
  }
}

function isDueSoon(iso){ if(!iso) return false; const t=new Date(iso).getTime(); return t <= Date.now() + 24*3600*1000 }

export default function App(){
  const [state, setState] = useState(()=>seed())
  const [auth, setAuth] = useState(()=>{
    try { return JSON.parse(localStorage.getItem(AUTH_KEY) || 'null') } catch { return null }
  })
  const [page, setPage] = useState('dashboard')
  const [query, setQuery] = useState('')
  const [filter, setFilter] = useState('')

  useEffect(()=> save(state), [state])
  useEffect(()=> { if (auth) localStorage.setItem(AUTH_KEY, JSON.stringify(auth)); else localStorage.removeItem(AUTH_KEY) }, [auth])

  if (!auth) return <Login onLogin={setAuth} />

  const user = auth
  const canDeleteAny = user.role === 'admin'
  const analytics = useMemo(()=> computeAnalytics(state.clients, state.inventory, state.requirements), [state])
  const dueClients = useMemo(()=> state.clients.filter(c=>isDueSoon(c.followUpAt)).sort((a,b)=> new Date(a.followUpAt)-new Date(b.followUpAt)), [state.clients])

  function addClient(data){
    const c = { id: 'c'+Date.now(), createdAt: nowISO(), ownerId: user.id, status: data.status || 'New', notes: data.notes||'', ...data }
    setState(s=> ({...s, clients:[c, ...s.clients]}))
  }
  function updateClientStatus(id, status){ setState(s=> ({...s, clients: s.clients.map(c=> c.id===id? {...c, status}: c)})) }
  function deleteClient(id){
    setState(s=> ({...s, clients: s.clients.filter(c=>{
      if (c.id!==id) return true
      return canDeleteAny || c.ownerId === user.id
    })}))
  }

  function postInventory(data){
    const p = { id: 'p'+Date.now(), ownerId:user.id, createdAt: nowISO(), images:[], type:'Residential', price:0, ...data }
    setState(s=> ({...s, inventory:[p, ...s.inventory]}))
  }
  function deleteInventory(id){
    setState(s=> ({...s, inventory: s.inventory.filter(p=>{
      if (p.id!==id) return true
      return canDeleteAny || p.ownerId === user.id
    })}))
  }

  function postRequirement(data){ const r = { id:'r'+Date.now(), postedBy:user.id, createdAt: nowISO(), tags:[], ...data }; setState(s=> ({...s, requirements:[r, ...s.requirements]})) }
  function deleteRequirement(id){
    setState(s=> ({...s, requirements: s.requirements.filter(r=>{
      if (r.id!==id) return true
      return canDeleteAny || r.postedBy === user.id
    })}))
  }

  function sendMessage(text){ if(!text?.trim()) return; const m = { id:'m'+Date.now(), from:user.id, text, time: nowISO() }; setState(s=> ({...s, chat:[...s.chat, m]})) }

  const visibleClients = state.clients.filter(c=>{
    if (filter && c.status !== filter) return false
    if (!query) return true
    const q = query.toLowerCase()
    return (c.name||'').toLowerCase().includes(q) || (c.phone||'').includes(q) || (c.notes||'').toLowerCase().includes(q)
  })

  return (
    <div className="container">
      <header className="header">
        <div className="logo-wrap">
          <img className="logo" src="https://homekart.co/logo.png" alt="HomeKart" />
          <div>
            <div className="brand">HomeKart CRM</div>
            <div className="muted" style={{fontSize:12}}>Signed in as {user.name} <span className={`badge ${user.role==='admin'?'admin':'agent'}`} style={{marginLeft:6}}>{user.role}</span></div>
          </div>
        </div>
        <div className="row">
          <button className="btn ghost" onClick={()=> setPage('dashboard')}>Dashboard</button>
          <button className="btn ghost" onClick={()=> setPage('clients')}>Clients</button>
          <button className="btn ghost" onClick={()=> setPage('inventory')}>Inventory</button>
          <button className="btn ghost" onClick={()=> setPage('requirements')}>Requirements</button>
          <button className="btn ghost" onClick={()=> setPage('chat')}>Chat</button>
          <button className="btn dark" onClick={()=> setAuth(null)}>Logout</button>
        </div>
      </header>

      {page==='dashboard' && (
        <div className="grid grid-3" style={{marginTop:16}}>
          <div className="card"><div className="title">Clients</div><div className="kpi">{analytics.totalClients}</div><div className="muted">Hot {analytics.hot} • Warm {analytics.warm} • New {analytics.new} • Closed {analytics.closed}</div></div>
          <div className="card"><div className="title">Inventory</div><div className="kpi">{analytics.totalInventory}</div><div className="muted">Properties posted</div></div>
          <div className="card"><div className="title">Requirements</div><div className="kpi">{analytics.totalRequirements}</div><div className="muted">Active requirements</div></div>

          <div className="card" style={{gridColumn:'1 / -1'}}>
            <div className="row" style={{justifyContent:'space-between'}}>
              <div className="title">Follow-ups due (next 24h)</div>
              <div className="muted">{dueClients.length} due</div>
            </div>
            <table className="table">
              <thead><tr><th>Name</th><th>Phone</th><th>Status</th><th>When</th><th>Owner</th></tr></thead>
              <tbody>
                {dueClients.length===0 && <tr><td colSpan={5} className="muted">No follow-ups due soon.</td></tr>}
                {dueClients.map(c=> (
                  <tr key={c.id}>
                    <td>{c.name}<div className="muted" style={{fontSize:12}}>{c.notes}</div></td>
                    <td>{c.phone}</td>
                    <td>{c.status}</td>
                    <td>{new Date(c.followUpAt).toLocaleString()}</td>
                    <td>{state.users.find(u=>u.id===c.ownerId)?.name||c.ownerId}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {page==='clients' && (
        <div className="grid grid-2" style={{marginTop:16}}>
          <div className="card"><div className="title">Add Client</div><ClientForm onSubmit={addClient} /></div>
          <div className="card">
            <div className="row" style={{justifyContent:'space-between'}}>
              <div className="title">Clients</div>
              <div className="row">
                <input className="input" placeholder="Search name/phone/notes" value={query} onChange={e=>setQuery(e.target.value)} />
                <select className="select" value={filter} onChange={e=>setFilter(e.target.value)}>
                  <option value="">All</option><option>New</option><option>Warm</option><option>Hot</option><option>Closed</option>
                </select>
              </div>
            </div>
            <table className="table">
              <thead><tr><th>Name</th><th>Phone</th><th>Status</th><th>Follow-up</th><th>Owner</th><th></th></tr></thead>
              <tbody>
                {visibleClients.map(c=> (
                  <tr key={c.id}>
                    <td>{c.name}<div className="muted" style={{fontSize:12}}>{c.notes}</div></td>
                    <td>{c.phone}</td>
                    <td>
                      <select className="select" value={c.status} onChange={e=>updateClientStatus(c.id, e.target.value)}>
                        <option>New</option><option>Warm</option><option>Hot</option><option>Closed</option>
                      </select>
                    </td>
                    <td>{c.followUpAt? new Date(c.followUpAt).toLocaleString(): <span className="muted">—</span>}</td>
                    <td>{state.users.find(u=>u.id===c.ownerId)?.name||c.ownerId}</td>
                    <td style={{textAlign:'right'}}>
                      {(canDeleteAny || c.ownerId===user.id) && <button className="btn warn" onClick={()=>deleteClient(c.id)}>Delete</button>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {page==='inventory' && (
        <div className="grid grid-2" style={{marginTop:16}}>
          <div className="card"><div className="title">Post Property</div><InventoryForm onSubmit={postInventory} /></div>
          <div className="card">
            <div className="title">All Inventory</div>
            <div className="stack">
              {state.inventory.map(p=> (
                <div key={p.id} className="card" style={{padding:12}}>
                  <div className="row" style={{justifyContent:'space-between'}}>
                    <strong>{p.title}</strong>
                    {(canDeleteAny || p.ownerId===user.id) && <button className="btn warn" onClick={()=>deleteInventory(p.id)}>Delete</button>}
                  </div>
                  <div className="muted" style={{fontSize:12}}>{p.location} • {p.type} • ₹{(p.price||0).toLocaleString()}</div>
                  <div style={{marginTop:8}}>{p.description}</div>
                  {p.images?.length>0 && (
                    <div className="row" style={{flexWrap:'wrap',marginTop:8}}>
                      {p.images.map((src,idx)=> <img alt="property" className="img" key={idx} src={src} />)}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {page==='requirements' && (
        <div className="grid grid-2" style={{marginTop:16}}>
          <div className="card"><div className="title">Post Requirement</div><RequirementForm onSubmit={postRequirement} /></div>
          <div className="card">
            <div className="title">All Requirements</div>
            <div className="stack">
              {state.requirements.map(r=> (
                <div key={r.id} className="pill" style={{justifyContent:'space-between'}}>
                  <div>
                    <strong>{r.title}</strong>
                    <span className="muted" style={{marginLeft:8,fontSize:12}}>by {state.users.find(u=>u.id===r.postedBy)?.name||r.postedBy} • {new Date(r.createdAt).toLocaleString()}</span>
                    <div style={{marginTop:6}} className="muted">{r.details}</div>
                    <div style={{marginTop:6}}>{(r.tags||[]).map(t=> <span className="badge" key={t}>{t}</span>)}</div>
                  </div>
                  {(canDeleteAny || r.postedBy===user.id) && <button className="btn warn" onClick={()=>deleteRequirement(r.id)}>Delete</button>}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {page==='chat' && (
        <div className="card" style={{marginTop:16}}>
          <div className="title">Team Chat</div>
          <ChatBox user={user} users={state.users} chat={state.chat} onSend={sendMessage} />
        </div>
      )}

      <div className="footer">HomeKart CRM • Vercel-ready demo (localStorage). For real auth & database, connect a Node/Mongo backend later.</div>
    </div>
  )
}

function ClientForm({ onSubmit }){
  const [form, setForm] = useState({ name:'', phone:'', notes:'', status:'New', followUpAt:'' })
  return (
    <div className="stack">
      <input className="input" placeholder="Name" value={form.name} onChange={e=>setForm({...form, name:e.target.value})} />
      <input className="input" placeholder="Phone" value={form.phone} onChange={e=>setForm({...form, phone:e.target.value})} />
      <textarea className="textarea" placeholder="Notes" value={form.notes} onChange={e=>setForm({...form, notes:e.target.value})} />
      <div className="row">
        <select className="select" value={form.status} onChange={e=>setForm({...form, status:e.target.value})}>
          <option>New</option><option>Warm</option><option>Hot</option><option>Closed</option>
        </select>
        <input className="input" type="datetime-local" value={form.followUpAt} onChange={e=>setForm({...form, followUpAt:e.target.value})} />
      </div>
      <div className="row">
        <button className="btn" onClick={()=>{ if(!form.name.trim()) return; onSubmit(form); setForm({ name:'', phone:'', notes:'', status:'New', followUpAt:'' }) }}>Add Client</button>
        <button className="btn ghost" onClick={()=> setForm({ name:'', phone:'', notes:'', status:'New', followUpAt:'' })}>Clear</button>
      </div>
    </div>
  )
}

function InventoryForm({ onSubmit }){
  const [form, setForm] = useState({ title:'', location:'', price:'', type:'Residential', description:'', images:[] })
  const fileRef = useRef(null)
  function handleFiles(files){
    if (!files || !files.length) return
    const list = Array.from(files)
    const readers = list.map(f => new Promise(res => { const r=new FileReader(); r.onload=()=>res(r.result); r.readAsDataURL(f) }))
    Promise.all(readers).then(urls => setForm(f => ({...f, images:[...f.images, ...urls]})))
  }
  return (
    <div className="stack">
      <input className="input" placeholder="Title" value={form.title} onChange={e=>setForm({...form, title:e.target.value})} />
      <div className="row">
        <input className="input" placeholder="Location" value={form.location} onChange={e=>setForm({...form, location:e.target.value})} />
        <input className="input" type="number" placeholder="Price" value={form.price} onChange={e=>setForm({...form, price:e.target.value})} />
        <select className="select" value={form.type} onChange={e=>setForm({...form, type:e.target.value})}>
          <option>Residential</option><option>Commercial</option><option>Plot</option>
        </select>
      </div>
      <textarea className="textarea" placeholder="Description" value={form.description} onChange={e=>setForm({...form, description:e.target.value})} />
      <input ref={fileRef} className="input" type="file" accept="image/*" multiple onChange={e=>handleFiles(e.target.files)} />
      <div className="row" style={{flexWrap:'wrap'}}>
        {form.images.map((src, idx) => <img key={idx} className="img" alt="preview" src={src} />)}
      </div>
      <div className="row">
        <button className="btn" onClick={()=>{ if(!form.title.trim()) return; onSubmit({ ...form, price: Number(form.price||0) }); setForm({ title:'', location:'', price:'', type:'Residential', description:'', images:[] }); if(fileRef.current) fileRef.current.value='' }}>Post Property</button>
        <button className="btn ghost" onClick={()=>{ setForm({ title:'', location:'', price:'', type:'Residential', description:'', images:[] }); if(fileRef.current) fileRef.current.value='' }}>Clear</button>
      </div>
    </div>
  )
}

function RequirementForm({ onSubmit }){
  const [form, setForm] = useState({ title:'', details:'', tags:'' })
  return (
    <div className="stack">
      <input className="input" placeholder="Short title (e.g. 3BHK Indiranagar 1.2Cr)" value={form.title} onChange={e=>setForm({...form, title:e.target.value})} />
      <textarea className="textarea" placeholder="Details" value={form.details} onChange={e=>setForm({...form, details:e.target.value})} />
      <input className="input" placeholder="tags (comma separated)" value={form.tags} onChange={e=>setForm({...form, tags:e.target.value})} />
      <div className="row">
        <button className="btn" onClick={()=>{ if(!form.title.trim()) return; onSubmit({ title:form.title, details:form.details, tags: form.tags.split(',').map(t=>t.trim()).filter(Boolean) }); setForm({ title:'', details:'', tags:'' }) }}>Post Requirement</button>
        <button className="btn ghost" onClick={()=> setForm({ title:'', details:'', tags:'' })}>Clear</button>
      </div>
    </div>
  )
}

function ChatBox({ user, users, chat, onSend }){
  const [text, setText] = useState('')
  const listRef = useRef(null)
  useEffect(()=>{ if(listRef.current) listRef.current.scrollTop = listRef.current.scrollHeight }, [chat])
  return (
    <div>
      <div ref={listRef} style={{maxHeight:300, overflow:'auto', border:'1px solid var(--border)', borderRadius:12, padding:8, background:'#fafafa'}}>
        {chat.map(m => (
          <div key={m.id} className="card" style={{padding:8, marginBottom:8}}>
            <div className="muted" style={{fontSize:12}}>
              {users.find(u=>u.id===m.from)?.name||m.from} • {new Date(m.time).toLocaleString()}
            </div>
            <div style={{marginTop:4}}>{m.text}</div>
          </div>
        ))}
      </div>
      <div className="row" style={{marginTop:8}}>
        <input className="input" placeholder="Write a message…" value={text} onChange={e=>setText(e.target.value)} onKeyDown={e=>{ if(e.key==='Enter'){ onSend(text); setText('') } }} />
        <button className="btn" onClick={()=>{ onSend(text); setText('') }}>Send</button>
      </div>
    </div>
  )
}

function Login({ onLogin }){
  const [email, setEmail] = useState('admin@homekart.co')
  const [password, setPassword] = useState('admin123')
  const [err, setErr] = useState('')

  function submit(){
    const u = USERS.find(u => u.email===email && u.password===password)
    if (!u) { setErr('Invalid credentials'); return }
    onLogin({ id: u.id, name: u.name, role: u.role, email: u.email })
  }

  return (
    <div className="login-wrap">
      <div className="login-card">
        <div className="login-header">
          <img className="login-logo" src="https://homekart.co/logo.png" alt="HomeKart" />
          <div>
            <div className="brand">HomeKart CRM</div>
            <div className="muted" style={{fontSize:12}}>Sign in to continue</div>
          </div>
        </div>
        <div className="stack">
          <input className="input" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
          <input className="input" type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} />
          {err && <div className="muted" style={{color:'#ef4444'}}>{err}</div>}
          <button className="btn" onClick={submit}>Sign In</button>
          <div className="muted" style={{fontSize:12}}>
            Demo users: admin@homekart.co / admin123 • agent1@homekart.co / agent123 (agents 1–10 share the same password)
          </div>
        </div>
      </div>
    </div>
  )
}

// Tiny self-checks
;(function tests(){
  const clients = [{status:'Hot'},{status:'Hot'},{status:'Warm'},{status:'New'},{status:'Closed'}]
  const a = computeAnalytics(clients, [{},{}], [{}])
  console.assert(a.totalClients===5, 'totalClients should be 5')
  console.assert(a.hot===2 && a.warm===1 && a.new===1 && a.closed===1, 'status counts incorrect')
  const soon = new Date(Date.now()+23*3600*1000).toISOString()
  const later = new Date(Date.now()+26*3600*1000).toISOString()
  console.assert(isDueSoon(soon)===true, 'isDueSoon true for <24h')
  console.assert(isDueSoon(later)===false, 'isDueSoon false for >24h')
})()